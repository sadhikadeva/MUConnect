//
//  MU_ConnectApp.swift
//  MU Connect
//
//  Created by Niyathi on 3/10/25.
//

import SwiftUI

@main
struct MU_ConnectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
