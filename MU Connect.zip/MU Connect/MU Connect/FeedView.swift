//
//  FeedView.swift
//  MU Connect
//
//  Created by Niyathi on 5/5/25.
//

import SwiftUI

struct FeedView: View {
    var body: some View {
        NavigationView {
            Text("Feed Page - Posts coming soon!")
                .navigationTitle("Feed")
        }
    }
}

#Preview {
    FeedView()
}
