//
//  MU_ConnectTests.swift
//  MU ConnectTests
//
//  Created by Niyathi on 3/10/25.
//

import Testing
@testable import MU_Connect

struct MU_ConnectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
